#!/usr/bin/env bash

read -p "\nWhere do you want to check the repo out to?" EDITORLOCATION

if [ "$EDITORLOCATION" != "" ]; then
  cd $EDITORLOCATION
else
  EDITORLOCATION=$(pwd)
fi

git clone https://github.com/ministryofjustice/fb-editor-node.git

cd fb-editor-node

npm install

