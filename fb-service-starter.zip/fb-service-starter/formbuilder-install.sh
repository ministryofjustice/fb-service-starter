#!/usr/bin/env bash

sh $(dirname "$0")/node-install.sh && source ~/.bash_profile && sh $(dirname "$0")/editor-install.sh